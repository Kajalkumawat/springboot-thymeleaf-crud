package com.login.loginregistrationpage.service;

import com.login.loginregistrationpage.entites.RegisterPart;

public interface RegisterService {

    public boolean registeruser(RegisterPart registerPart);
    public RegisterPart loginUser(String email,String password);
}
