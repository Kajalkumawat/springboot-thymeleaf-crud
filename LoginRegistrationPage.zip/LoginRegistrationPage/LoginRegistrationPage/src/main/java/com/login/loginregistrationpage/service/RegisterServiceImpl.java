package com.login.loginregistrationpage.service;

import com.login.loginregistrationpage.entites.RegisterPart;
import com.login.loginregistrationpage.repositories.RegisterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterServiceImpl implements RegisterService{

    @Autowired
    private RegisterRepository registerRepository;

    @Override
    public boolean registeruser(RegisterPart registerPart) {
        try{
            registerRepository.save(registerPart);
            return true;
        }
        catch (Exception ex){
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public RegisterPart loginUser(String email, String password) {
        RegisterPart validUser=registerRepository.findByEmail(email);

        if(validUser !=null && validUser.getPassword().equals(password)){
        return validUser;
        }
        return null;
    }
}
