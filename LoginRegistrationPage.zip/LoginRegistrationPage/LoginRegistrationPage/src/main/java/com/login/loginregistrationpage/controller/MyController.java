package com.login.loginregistrationpage.controller;

import com.login.loginregistrationpage.entites.RegisterPart;
import com.login.loginregistrationpage.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MyController {

    @Autowired
    private RegisterService registerService;

    @GetMapping("/regPage")
    //want to stored front end data into the database
    public String openRegPage(Model model){
        //want to add the data
        model.addAttribute("registerPart",new RegisterPart());
        return "register";
    }

    //want to store the data into the data base through thymleaf :
    @PostMapping("/regForm")
    public String submitRegForm(@ModelAttribute("registerPart") RegisterPart registerPart,Model model){
        boolean status =registerService.registeruser(registerPart);
        if(status){
            model.addAttribute("successfull","user registered successfully ");
        }
        else{
            model.addAttribute("error message","user does not registered successfully ");
        }
        return "register";
    }

    //it check login page is working or not into the backend:
    @GetMapping("/loginPage")
    public String openLogicPage(Model model){
        model.addAttribute("loginPart",new RegisterPart());
        return "login";
    }

    //now check the data is present into the database or not :
    @PostMapping("/loginPage")
    public String submitLoginForm(@ModelAttribute("loginPart") RegisterPart registerPart,Model model){
       RegisterPart validUser= registerService.loginUser(registerPart.getEmail(),registerPart.getPassword());
       if(validUser!=null){
           return "profile";
       }
       else{
           model.addAttribute("error msg","email id and password does not matched ");
           return "login";
       }
    }
}
