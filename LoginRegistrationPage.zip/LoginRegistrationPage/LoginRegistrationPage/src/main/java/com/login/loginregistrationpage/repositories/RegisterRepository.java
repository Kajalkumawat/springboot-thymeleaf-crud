package com.login.loginregistrationpage.repositories;

import com.login.loginregistrationpage.entites.RegisterPart;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface RegisterRepository extends JpaRepository<RegisterPart,Integer> {
    RegisterPart findByEmail(String email);
}
