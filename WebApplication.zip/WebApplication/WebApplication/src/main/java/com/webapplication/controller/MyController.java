package com.webapplication.controller;

import com.webapplication.entites.RegisterPart;
import com.webapplication.service.RegisterPartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
//MyController :it is used to handle the request part of the anchor tag through controller
public class MyController {

    @Autowired
    private RegisterPartService registerPartService;

    //regPage name is same on the anchor tag of href
    @GetMapping("regPage")
    public String openRegPage(Model model){
        //return register :it is used to open the register file of the html
        //when give hello then connect with hello file when if we want to connect with register.html then wirte register only
        //want to stored front end part of data is stored into the backend part : then load the data is Model class :
        model.addAttribute("registerPart",new RegisterPart());
        return "register";
    }

    //want to store the data :
    @PostMapping("/regForm")
    //ModelAttribute is used to access the data of model from the get mapping
    public String submitRegForm(@ModelAttribute("registerPart") RegisterPart registerPart,Model model){
       boolean status= registerPartService.registerUser(registerPart);
        if(status){
            //want to print message :
            model.addAttribute("success message","user is registerd successfully");
        }
        else{
            model.addAttribute("error message","you are not registered in company ");
        }
        return "register";
    }

    //want to check login page is working or not :
    @GetMapping("/loginPage")
    public String loginPageOpen(Model model) {
        model.addAttribute("registerPart", new RegisterPart());
        return "login";
    }


    //login form :
    @PostMapping("/loginForm")
    public String submitLoginForm(@ModelAttribute("registerPart") RegisterPart registerPart,Model model){
       RegisterPart validUser= registerPartService.loginUser(registerPart.getEmail(),registerPart.getPassword());

       if(validUser!=null){
           model.addAttribute("valid","you are the valid user ");
           System.out.println("hiiii");
           return "profile";
       }
       else {
           model.addAttribute("error message","email id and password did not matched ");
           return "login";
       }
    }
}
