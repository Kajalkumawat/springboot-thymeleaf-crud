package com.webapplication.service;

import com.webapplication.entites.RegisterPart;
import com.webapplication.repositories.RegisterPartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterPartServiceImpl implements RegisterPartService{

    @Autowired
    private RegisterPartRepository registerPartRepository;

    @Override
    public boolean registerUser(RegisterPart registerPart) {
        try{
            registerPartRepository.save(registerPart);
            return true;
        }
        catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public RegisterPart loginUser(String email, String password) {
       RegisterPart validUser= registerPartRepository.findByEmail(email);
       if(validUser!=null && validUser.getPassword().equals(validUser)){
           return validUser;
       }
        return validUser;
    }
}
