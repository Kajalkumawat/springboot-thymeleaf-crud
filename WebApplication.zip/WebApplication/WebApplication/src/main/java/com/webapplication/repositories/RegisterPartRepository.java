package com.webapplication.repositories;

import com.webapplication.entites.RegisterPart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegisterPartRepository extends JpaRepository<RegisterPart,Integer> {
    RegisterPart findByEmail(String email);
}
