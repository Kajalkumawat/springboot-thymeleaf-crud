package com.webapplication.service;

import com.webapplication.entites.RegisterPart;

public interface RegisterPartService {
    public boolean registerUser(RegisterPart registerPart);
    public RegisterPart loginUser(String email,String password);
}
